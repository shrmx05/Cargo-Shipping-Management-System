class Node:
    def __init__(self,key):
        self.key=key
        self.right=None
        self.left=None
        self.parent=None
        self.height=0